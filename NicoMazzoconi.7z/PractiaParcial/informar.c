#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "llamada.h"
#include "utn.h"
#include "abonado.h"

int abonadoMasReclamos(Llamada* arrayLlamada, int limiteLlamada, Abonado* arrayAbonado, int limiteAbonado)
{
    int retorno = -1;
    int i, j;
    for(i = 0; i < limiteLlamada; i++)
    {
        for(j = 1; j < limiteLlamada; j++)
        {
            if(arrayLlamada[i].idAbonado == arrayAbonado[j])
            {

            }
        }
    }
    return retorno;
}
