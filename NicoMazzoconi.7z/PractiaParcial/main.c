#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "abonado.h"
#include "llamada.h"
#include "utn.h"
#define QTY 10
#define QTY_LLAMADA 100

int main()
{
    Abonado array[QTY];
    Llamada arrayLlamada[QTY_LLAMADA];
    int menu;
    int auxiliarId;

    abonado_init(array,QTY);
    llamada_init(arrayLlamada, QTY_LLAMADA);
    do
    {
        getValidInt("\n1.Alta Abonado\n2.Baja Abonado\n3.Modificar Abonado\n4.Mostrar Abonado\n5.Alta Llamada\n6.Baja Llamada\n7.Modificar Llamada\n8.Mostrar Llamadas\n9.Salir\n","\nNo valida\n",&menu,1,9,1);
        switch(menu)
        {
            case 1:
                abonado_alta(array,QTY);
                break;
            case 2:
                getValidInt("ID?","\nNumero valida\n",&auxiliarId,0,200,2);
                abonado_baja(array,QTY,auxiliarId);
                break;
            case 3:
                getValidInt("ID?","\nNumero valida\n",&auxiliarId,0,200,2);
                abonado_modificacion(array,QTY,auxiliarId);
                break;
            case 4:
                abonado_mostrar(array,QTY);
                break;
            case 5:
                llamada_alta(arrayLlamada, QTY_LLAMADA);
                break;
            case 6:
                getValidInt("ID?","\nNumero valida\n",&auxiliarId,0,200,2);
                llamada_baja(arrayLlamada, QTY_LLAMADA, auxiliarId);
                break;
            case 7:
                getValidInt("ID?","\nNumero valida\n",&auxiliarId,0,200,2);
                llamada_modificacion(arrayLlamada, QTY_LLAMADA, auxiliarId);
                break;
            case 8:
                llamada_mostrar(arrayLlamada, QTY_LLAMADA);
        }

    }while(menu != 9);

    return 0;
}
