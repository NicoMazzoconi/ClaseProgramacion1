#include "llamada.h"
#include "abonado.h"
#ifndef INFORMAR_H_INCLUDED
#define INFORMAR_H_INCLUDED



#endif // INFORMAR_H_INCLUDED
int abonadoMasReclamos(Llamada *arrayLlamada, int limiteLlamada, Abonado *arrayAbonado, int limiteAbonado);
